export default function Page() {
    return <p>customers Page</p>;
  }