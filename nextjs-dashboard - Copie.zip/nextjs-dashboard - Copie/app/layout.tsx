"use client";
import "@/app/ui/global.css";
import * as React from "react";
import { inter } from "@/app/ui/fonts";
import AcmeLogo from "@/app/ui/acme-logo";
import { Providers } from "./providers";
import { Metadata } from "next";
import { Accordion, AccordionItem } from "@nextui-org/react";
import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  Link,
  DropdownItem,
  DropdownTrigger,
  Dropdown,
  DropdownMenu,
  Avatar,
} from "@nextui-org/react";
import { Button } from "@nextui-org/react";
// export const metadata: Metadata = {
//   title: {
//     template: "%s | Acme Dashboard",
//     default: "Acme Dashboard",
//   },
//   description: "The official Next.jsCourse Dashboard, built with App Router.",
//   metadataBase: new URL("https://next-learn-dashboard.vercel.sh"),
// };

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className="light">
      {/* <body>{children}</body> */}
      <body className={`${inter.className} antialiased`}>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
