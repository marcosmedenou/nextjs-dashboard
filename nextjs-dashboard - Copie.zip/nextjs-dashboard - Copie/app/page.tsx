'use client'
import AcmeLogo from "@/app/ui/acme-logo";
import React from "react";
import { ArrowRightIcon } from "@heroicons/react/24/outline";
import Link from "next/link";
import { lusitana } from "./ui/fonts";
import Image from "next/image";
import Header  from "@/app/ui/partials/header";
import { Button } from "@nextui-org/react";

import {Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, useDisclosure, Checkbox, Input} from "@nextui-org/react";
// import styles from '@/app/ui/home.module.css' // include css module in tsx app
export default function Page() {
  const {isOpen, onOpen, onOpenChange} = useDisclosure();
  return (
 <main>
<Header></Header>
 </main>
  );
}
